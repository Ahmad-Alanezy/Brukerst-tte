function submitSurvey() {
    var formData = {
        question1: document.querySelector('input[name="question1"]:checked').value,
        question2: document.querySelector('input[name="question2"]:checked').value,
        question3: document.querySelector('input[name="question3"]:checked').value
    };

    // Her kan du legge til kode for å behandle eller vise dataene, for eksempel logge dem til konsollen
    console.log(formData);

    alert("Spørreundersøkelse sendt inn!");
}

document.getElementById("surveyForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    // Get form data
    var formData = {
        question1: document.querySelector('input[name="question1"]:checked').value,
        question2: document.querySelector('input[name="question2"]:checked').value,
        question3: document.querySelector('input[name="question3"]:checked').value
    };

    // Here, you can process the form data as needed
    console.log(formData);

    // Redirect to another HTML page
    window.location.href = "hovedside.html";
});
